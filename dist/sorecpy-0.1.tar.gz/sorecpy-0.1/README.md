#mypackage
This library is created to do simple computations using functions that will carry out the said computations.

##building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/sinethembamanisi/sorecpy.git`

##updating this package from github
`pip install --upgrade git+https://github.com/sinethembamanisi/sorecpy.git`
